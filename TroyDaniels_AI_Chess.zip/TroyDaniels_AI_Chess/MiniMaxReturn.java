

public class MiniMaxReturn {
	public int[][] move;
	public double value;
	
	public MiniMaxReturn() {
		this.value = 0;
	}
}
